import sqlite3
import requests
import csv
import time

DB_NAME = "dura.sqlite"

# SPARQL query template
SPARQL_ENDPOINT = "https://query.wikidata.org/sparql"

# Function to log queries and results
def log_query(property_type, value):
    print(f"Querying Wikidata with {property_type} = {value}")

# Function to query Wikidata based on the available fields
def query_wikidata(property_type, value):
    query = f'''
    SELECT ?item ?itemLabel ?description ?instanceOfLabel ?materialLabel ?altLabel ?depictsLabel ?genreLabel WHERE {{
      ?item wdt:{property_type} "{value}" .
      OPTIONAL {{ ?item rdfs:label ?itemLabel . FILTER(LANG(?itemLabel) = "en") }}
      OPTIONAL {{ ?item schema:description ?description . FILTER(LANG(?description) = "en") }}
      OPTIONAL {{ ?item skos:altLabel ?altLabel . FILTER(LANG(?altLabel) = "en") }}
      OPTIONAL {{ ?item wdt:P31 ?instanceOf . ?instanceOf rdfs:label ?instanceOfLabel . FILTER(LANG(?instanceOfLabel) = "en") }}
      OPTIONAL {{ ?item wdt:P186 ?material . ?material rdfs:label ?materialLabel . FILTER(LANG(?materialLabel) = "en") }}
      OPTIONAL {{ ?item wdt:P136 ?genre . ?genre rdfs:label ?genreLabel . FILTER(LANG(?genreLabel) = "en") }}
      OPTIONAL {{ ?item wdt:P180 ?depicts . ?depicts rdfs:label ?depictsLabel . FILTER(LANG(?depictsLabel) = "en") }}
    }}
    LIMIT 10
    '''
    log_query(property_type, value)
    try:
        response = requests.get(SPARQL_ENDPOINT, params={'query': query, 'format': 'json'})
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error querying Wikidata: {e}")
        return None
    except ValueError as e:
        print(f"Error decoding JSON response: {e}")
        return None

# Function to parse results and return relevant info
def get_item_info_from_wikidata(accession, negative_number, upload_fname):
    # Try querying with negative number first
    data = query_wikidata('P217', negative_number)  # Assume negative_number is the inventory number
    if not data or not data['results']['bindings']:
        # If no results, try using accession number
        data = query_wikidata('P217', accession)
        if not data or not data['results']['bindings']:
            # Lastly, try using upload_fname (assuming it's linked to the media file)
            data = query_wikidata('P18', upload_fname)
            if not data or not data['results']['bindings']:
                # Fallback: try searching by title or description if nothing works
                data = query_wikidata('rdfs:label', negative_number)

    if data and data['results']['bindings']:
        for result in data['results']['bindings']:
            item_info = result
            label = item_info.get('itemLabel', {}).get('value', 'N/A')
            description = item_info.get('description', {}).get('value', 'N/A')
            alt_label = item_info.get('altLabel', {}).get('value', 'N/A')
            instance_of = item_info.get('instanceOfLabel', {}).get('value', 'N/A')
            material = item_info.get('materialLabel', {}).get('value', 'N/A')
            depicts = item_info.get('depictsLabel', {}).get('value', 'N/A')
            genre = item_info.get('genreLabel', {}).get('value', 'N/A')

            # Print or return multiple results if applicable
            print(f"Result Found: Label: {label}, Description: {description}, Instance Of: {instance_of}, Material: {material}, Depicts: {depicts}, Genre: {genre}")
            return (negative_number, label, description, alt_label, instance_of, material, depicts, genre)
    else:
        return (negative_number, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A')


# Connect to the database and fetch records
def fetch_data_from_database():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    
    # Fetch accession, negative_number, and upload_fname from the objects table
    cur.execute('SELECT accession, negative_number, upload_fname FROM objects')
    rows = cur.fetchall()

    cur.close()
    conn.close()
    
    return rows

# Query Wikidata for each item in the database and write results to a CSV file
def process_and_save_results():
    data = fetch_data_from_database()
    results = []
    
    for row in data:
        accession, negative_number, upload_fname = row
        result = get_item_info_from_wikidata(accession, negative_number, upload_fname)
        results.append(result)

        time.sleep(1)  # Introduce a 1-second delay between queries

    # Save results to a CSV file
    with open('wikidata_output.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Inventory Number', 'Label', 'Description', 'Also Known As', 'Instance Of', 'Material', 'Depicts', 'Genre'])
        writer.writerows(results)

    print("Data retrieved and saved successfully.")

# Run the process
if __name__ == "__main__":
    process_and_save_results()
